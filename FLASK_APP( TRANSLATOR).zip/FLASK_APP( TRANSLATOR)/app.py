from flask import Flask, request, render_template, jsonify
from datetime import date
from googletrans import Translator
from gtts import gTTS
import os

app = Flask(__name__)

translator = Translator()

def translatetext(text, target_lang):
    translation = translator.translate(text, dest=target_lang)
    return translation.text

def text_to_speech(text, lang_code):
    tts = gTTS(text=text, lang=lang_code, slow=False)
    tts.save('temp.mp3')
    os.system('start temp.mp3')  # Open the default audio player to play the file

@app.route('/')
def home():
    return render_template('main.html', datetoday2=date.today().strftime("%d-%B-%Y"), res='')

@app.route('/translate', methods=['POST'])
def translate():
    input_text = request.form['sourcetext']
    target_lang = request.form['languages']

    # Translate to the target language
    res = translatetext(input_text, target_lang)

    return render_template('main.html', datetoday2=date.today().strftime("%d-%B-%Y"), res=res)

@app.route('/speak_english', methods=['POST'])
def speak_english():
    data = request.get_json()
    sourcetext = data['sourcetext']

    # Create a gTTS object
    tts = gTTS(text=sourcetext, lang='en', slow=False)

    # Save the audio file
    tts.save('static/english.mp3')

    return jsonify({'success': True})

# New route for Translated TTS
@app.route('/speak_translated', methods=['POST'])
def speak_translated():
    data = request.get_json()
    translated_text = data['translatedText']
    language = data['languages']

    # Create a gTTS object with the specified language
    tts = gTTS(text=translated_text, lang=language, slow=False)

    # Save the audio file
    tts.save('static/translated.mp3')

    return jsonify({'success': True})


@app.route('/speak', methods=['POST'])
def speak():
    input_text = request.form['sourcetext']
    text_to_speech(input_text, 'en')  # Adjust 'en' to the appropriate language code
    return render_template('main.html', datetoday2=date.today().strftime("%d-%B-%Y"), res='')


if __name__ == '__main__':
    app.run(debug=True)
